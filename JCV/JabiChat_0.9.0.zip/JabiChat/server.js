//Setting up the variables and stuff
var http = require("http");
var express = require("express");
var app = express();
var server = http.createServer(app);
var { Server } = require("socket.io");
var io = new Server(server, {
  //Prevents it from just closing a socket when 1MB is sent
  //Now craps out at around 100MB
  maxHttpBufferSize: 1.1e8
});

//Stores main.html in variable for log-in reasons
var fs = require('fs');
var ChatHTML = "";
fs.readFile("main.html", (err, data) => {
  ChatHTML = data.toString();
});

//Manipulates main page HTML string for formatting
var HTMLSan = function(HTML, DPR) {
  //Code for parsing was copied from SQLSan
  Temp = -2
  while(HTML.indexOf("px", Temp + 2) > -1) {
    Temp = HTML.indexOf("px", Temp + 2);
    Temp2 = 0;
    while(HTML[Temp - Temp2] !== " ")
      Temp2++;
    Num = parseInt(HTML.substring(Temp - Temp2 + 1, Temp));
    HTML = HTML.substring(0, Temp - Temp2 + 1) + (Num * DPR) + HTML.substring(Temp);
    Temp = HTML.indexOf("px", Temp);
  }
  return HTML;
}


//Log in and open SQL connection
var mysql = require("mysql2");
const e = require("express");
var query = "";
var SQLFN = function () {}
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "", //<=== PUT YOUR SQL PASSWORD HERE (within the quote marks)
  database: "app2"
});
connection.connect((err) => {
  if (err) {
    console.log("Error occurred", err);
  } else {
    console.log("Connected to MySQL");
  }
});

//Sanitizes strings to prevent SQL injection; important for security
var SQLSan = function (q) {
  if(q) { //Needed to prevent server crashing from fake socket emits
    Temp = -2 //Temp is needed to actually move through the string instead of getting stuck
    while(q.indexOf("\\", Temp + 2) > -1) {
      Temp = q.indexOf("\\", Temp + 2); //Two is added to make temp get past the two chars
      q = q.substring(0, Temp) + "\\" + q.substring(Temp);
    }
    Temp = -2
    while(q.indexOf("\"", Temp + 2) > -1) {
      Temp = q.indexOf("\"", Temp + 2);
      q = q.substring(0, Temp) + "\\" + q.substring(Temp);
    }
    return "\"" + q + "\"";
  }
}

//Sends login page to user
app.use(express.static(__dirname));
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/login.html');
});

var NumUsers = 0;
var Online = [];
//Handles socket events for each user
io.on('connection', (socket) => {
  socket.Pass = Math.random();
  socket.Recent = [];
  NumUsers++;
  console.log('User connected (' + NumUsers + ')');

  //On database request, does what is specified in the Dict
  socket.on("db", (D) => {
    if(D) {
      if(D.Type === "PullMessages") {
        query = "SELECT messages.MessageID, messages.Content, messages.UserID, messages.RoomID, messages.ReplyID, messages.TimeSent, users.UserName FROM messages";
        query += " LEFT JOIN users ON messages.UserID = users.UserID WHERE messages.MessageID > " + D.Recent + " AND messages.RoomID = " + D.Room + " ORDER BY MessageID DESC LIMIT 100;"
        SQLFN = function(D, result, socket) {
          socket.emit("ReceiveMessages", {
            Messages: result,
            Room: D.Room
          });
        }
      } else if(D.Type === "Send") {
        if(!D.Reply)
          D.Reply = 0;
        console.log("User #" + D.ID + " sending message in room #" + D.Room + "...");
        query = "INSERT INTO messages (Content, UserID, RoomID, ReplyID) VALUES (" + SQLSan(D.Message) + "," + D.ID + "," + D.Room + "," + D.Reply + ");";
        SQLFN = function(D) {
          console.log("Sent!");
          io.emit("Update", {
            Room: D.Room,
            System: D.System,
            File: false
          });
        }
      } else if(D.Type === "Edit") {
        console.log("Editing message #" + D.Message + "...");
        query = "UPDATE messages SET Content = " + SQLSan(D.Content + "<span style='font-size: 8px'><i> (edited)</i></span>") + " WHERE MessageID = " + D.Message + ";";
        SQLFN = function(D, result) {
          console.log("Edited.")
          io.emit("DynEditMsg", {
            M: D.Message,
            Content: D.Content + "<span style='font-size: 8px'><i> (edited)</i></span>"
          });
        }
      } else if(D.Type === "DelMsg") {
        console.log("Deleting message #" + D.M);
        query = "UPDATE messages SET Content = '[DELETED MESSAGE]' WHERE MessageID = " + D.M + ";";
        SQLFN = function(D, result) {
          console.log("Deleted.");
          io.emit("DynEditMsg", {
            M: D.M,
            Content: "[DELETED MESSAGE]"
          });
        }
      } else if(D.Type === "SendFile") {
        if(!D.Reply)
          D.Reply = 0;
        console.log("User #" + D.ID + " sending file in room #" + D.Room + "...");
        query = "CALL SendFile(" + D.ID + ", " + D.Room + ", \"[UNSTORED FILE (" + D.FileName + ")]\", " + D.Reply + ");";
        SQLFN = function(D, result) {
          console.log("Sent!");
          io.emit("Update", {
            Room: D.Room,
            System: {Check: false},
            File: D.File,
            FileType: D.FileType,
            FileName: D.FileName,
            ID: result[0][0],
            ReplyID: D.Reply
          });
        }
      } else if(D.Type === "LogIn") {
        console.log("Logging in user #" + D.ID + "....");
        query = "CALL GetUserInfo(" + D.ID + "," + SQLSan(D.P) + ");";
        SQLFN = function (D, result) {
          if(result[3].length === 1) {
            console.log("User '" + result[0][D.ID].UserName + "' (#" + D.ID + ") authenticated.");
            
            let Check = false //For activity stuff
            for(let i = 0; i < Online.length; i++) {
              if(Online[i].ID === parseInt(D.ID)) {
                Online[i].Num++;
                Check = true;
                break;
              }
            }
            if(!Check) {
              Online.push({
                ID: parseInt(D.ID),
                Num: 1
              });
              console.log("Updating activity...");
              io.emit("ActivityUpdate", {
                ID: parseInt(D.ID),
                A: "A"
              });
            } 
            console.log(Online);

            let UR = [];
            let j = 0;
            for(let i = 0; i < result[1].length; i++) {
              UR.push({
                ID: [],
                Perms: []
              });
              while(j < result[2].length && result[2][j].RoomID === result[1][i].RoomID) {
                UR[i].ID.push(result[2][j].UserID);
                UR[i].Perms.push(result[2][j].Perms);
                j++;
              }
            }

            socket.ID = parseInt(D.ID);
            socket.emit("LoggedIn", {
              html: HTMLSan(ChatHTML, D.DPR),
              ID: parseInt(D.ID),
              Name: result[0][D.ID].UserName,
              Rooms: result[1],
              UData: result[0],
              UserRels: UR
            });
          } else {
            console.log("Failed to authenticate user #" + D.ID + ".");
            socket.emit("LogFail", {});
          }
        }
      } else if(D.Type === "CreateAccount") {
        console.log("Creating account...");
        query = "CALL CreateAccount(" + SQLSan(D.UN) + "," + SQLSan(D.P) + ");";
        SQLFN = function (D, result) {
          console.log("Account '" + D.UN + "' (#" + result[0][0].ID + ") created!");
          Online.push({
            ID: result[0][0].ID,
            Num: 1
          });
          console.log(Online);
          socket.ID = result[0][0].ID;
          socket.emit("LoggedIn", {
            html: HTMLSan(ChatHTML, D.DPR),
            ID: result[0][0].ID,
            Name: D.UN,
            Rooms: [],
            UData: result[1],
            UserRels: []
          });
          setTimeout(() => { //Delay necessary for inv to appear on client
            io.emit("Invite", {
              User: result[0][0].ID,
              Room: 1,
              Name: "Public Chatroom",
              UserRels: result[2],
              UserName: D.UN,
              Sender: 0
            });
          }, 500);
        }
      } else if(D.Type === "SendInv") {
        console.log("Sending invite to room #" + D.Room + " to user #" + D.User + "...");
        query = "CALL Invite(" + D.User + ", " + D.Room + ");";
        SQLFN = function (D, result) {
          if(result[1].affectedRows > 0) {
            console.log("Invite sent!");
            let UR = {
              ID: [],
              Perms: []
            }
            for(let i = 0; i < result[0].length; i++) {
              UR.ID.push(result[0][i].UserID);
              UR.Perms.push(result[0][i].Perms);
            }
            io.emit("Invite", {
              User: D.User,
              Room: D.Room,
              Name: D.Name,
              UserRels: UR,
              Sender: D.Sender
            });
          } else {
            console.log("Invite failed! User already has relation to room or does not exist.");
            socket.emit("InvErr", {});
          }
        }
      } else if(D.Type === "RI") {
        if(D.Accepted) {
          console.log("Room #" + D.Room + " invite accepted by user #" + D.User + ".");
          query = "UPDATE userrooms SET Perms = 'U' WHERE UserID = " + D.User + " AND RoomID = " + D.Room + " AND Perms = 'I';";
        } else {
          console.log("Room #" + D.Room + " invite for user #" + D.User + " revoked/declined.");
          query = "DELETE FROM userrooms WHERE UserID = " + D.User + " AND RoomID = " + D.Room + ";";
        }
        SQLFN = function () {
          io.emit("RemInv", {
            Room: D.Room,
            User: D.User
          });
        };
      } else if(D.Type === "ChangePerm") {
        console.log("Changing permissions of user #" + D.ID + " in room #" + D.Room + "...");
        query = "UPDATE userrooms SET Perms = " + SQLSan(D.Perm) + " WHERE UserID = " + D.ID + " AND RoomID = " + D.Room + ";";
        SQLFN = function () {};
      } else if(D.Type === "SetUDesc") {
        console.log("User #" + D.ID + " setting their description.");
        query = "UPDATE users SET Descr = " + SQLSan(D.Desc) + " WHERE UserID = " + D.ID + ";";
        SQLFN = function () {
          io.emit("DescUpdate", {
            ID: D.ID,
            Desc: D.Desc
          });
        };
      } else if(D.Type === "RenameRoom") {
        console.log("Room #" + D.Room + " being renamed to '" + D.Name + "'.");
        query = "UPDATE rooms SET RoomName = " + SQLSan(D.Name) + " WHERE RoomID = " + D.Room + ";";
        SQLFN = function () {};
      } else if(D.Type === "LeaveRoom") {
        console.log("User #" + D.ID + " leaving room #" + D.Room + ".");
        query = "DELETE FROM userrooms WHERE UserID = " + D.ID + " AND RoomID = " + D.Room + ";";
        SQLFN = function () {};
      } else if(D.Type === "CreateRoom") {
        console.log("Creating room '" + D.Name + "'...");
        query = "CALL CreateRoom(" + D.ID + "," + SQLSan(D.Name) + ");";
        SQLFN = function (D, result, socket) {
          console.log("Room '" + D.Name + "' (#" + result[0][0].ID + ") created.");
          socket.emit('AddRoom', {
            ID: result[0][0].ID,
            Name: D.Name
          });
        }
      } else if(D.Type === "ChangeAcc") {
        console.log("Changing account info of user #" + D.ID + "...");
        query = "UPDATE users SET UserName = " + SQLSan(D.U) + ", Pass = " + SQLSan(D.NP) + " WHERE UserID = " + D.ID + " AND Pass = " + SQLSan(D.OP) + ";";
        SQLFN = function (D, result) {
          if(result.affectedRows === 1) {
            console.log("Succeeded!");
            io.emit("SignOut2", {
              ID: D.ID
            });
          } else {
            console.log("Failed.");
            socket.emit("ChangeFail", {});
          }
        };
      } else if(D.Type === "DelAcc") {
        console.log("Deleting account of user #" + D.ID + "...");
        query = "UPDATE users SET Pass = '', Activity = 'D' WHERE UserID = " + D.ID + " AND Pass = " + SQLSan(D.P) + ";";
        SQLFN = function (D, result) {
          if(result.affectedRows === 1) {
            console.log("Succeeded!");
            io.emit("SignOut2", {
              ID: D.ID
            });
            console.log("Updating activity...");
            io.emit("ActivityUpdate", {
              ID: D.ID,
              A: "D"
            });
          } else {
            console.log("Failed.");
            socket.emit("DelFail", {});
          }
        };
      }
      var Run = function (C, FN) {
        C.query(query, function (err, result) {
          if(err)
            console.log(err);
          else {
            FN(D, result, socket);
          }
        });
      };
      if(D.Type === "LogIn" || D.Type === "CreateAccount" || D.Pass === socket.Pass)
        Run(connection, SQLFN);
    }
  });
  socket.on("DataPing", (Data) => {
    socket.emit("DataRespond", {
      ID: Data.ID,
      Name: Data.Name,
      Rooms: Data.Rooms,
      UData: Data.UData,
      UserRels: Data.UserRels,
      Pass: socket.Pass
    });
  });
  socket.on("Recent", (Data) => {
    socket.Recent = Data.List;
  });

  //Double emit thing for sending the signout request to every socket
  socket.on("SignOut", (Data) => {
    if(socket.Pass === Data.Pass)
      io.emit("SignOut2", {
        ID: Data.ID
      });
  });
  socket.on("SignOut3", (Data) => {
    if(Data && parseInt(socket.ID) === parseInt(Data.ID))
      socket.disconnect();
  })

  //Handles user disconnection
  socket.on('disconnect', () => {
    NumUsers--;
    if(socket.ID)
      console.log("User #" + socket.ID + " disconnected (" + NumUsers + ")");
    else
      console.log('Client disconnected (' + NumUsers + ')');
    for(let i = 0; i < socket.Recent.length; i++) { //For log-on notifs
      if(socket.Recent[i].Recent) {
        query = "UPDATE userrooms SET Recent = " + socket.Recent[i].Recent + " WHERE UserID = ";
        query += socket.Recent[i].User + " AND RoomID = " + socket.Recent[i].ID + ";";
        connection.query(query, function (err, result) {
          if(err)
            console.log(err);
        });
      }
    }
    if(socket.ID) {
      for(let i = 0; i < Online.length; i++) { //For activity stuff
        if(Online[i].ID == socket.ID) {
          Online[i].Num--;
          if(Online[i].Num === 0) {
            Online.splice(i, 1);
            query = "UPDATE users SET Activity = 'O' WHERE UserID = " + socket.ID + " AND NOT Activity = 'D';";
            connection.query(query, function (err, result) {
              if(err)
                console.log(err);
              else if(result.affectedRows === 1) {
                console.log("User #" + socket.ID + " marked offline.")
                console.log("Updating activity...");
                io.emit("ActivityUpdate", {
                  ID: socket.ID,
                  A: "O"
                });
              }
            });
          }
          break;
        }
      }
      console.log(Online);
    }
  });
});

//Starts server
server.listen(80, () => {
  console.log('listening on *:80');
});

//Sends a dummy query every 30 minutes to maintain SQL connection indefinitely
setInterval(() => {
  connection.query("SELECT * FROM users", function (err, result) {
    console.log("Queried.");
  });
}, 1800000);