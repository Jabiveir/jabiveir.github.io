I made this from 2 to 5 AM with only a vague memory of PyGame and a bad idea

I highly recommend trying every way to close this "virus" (preferrably with
your volume lowered) before using "End Task" in Task Manager to actually stop
the program. If you are evil, you can remove this part of the ReadMe before
sharing this with a friend (or, more likely, an enemy)

You can also customize the song it plays and the image/icon it displays simply
by changing the files and renaming them to "Weezer.mp3" or "Weezer.jpg" (the
image must be 600x600 otherwise it'll look weird I think)

Audio source: https://www.youtube.com/watch?v=ESOyXKytHr4