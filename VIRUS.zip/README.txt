I made this from 2 to 5 AM with only a vague memory of PyGame and a bad idea

Seeing as how this is an actual for reals virus (at least as much as I could
make it), I feel obligated to mention that you can quite easily close it by
using End Task in Task Manager (if you don't know how, look it up)

You can also customize the song it plays and the image/icon it displays simply
by changing the files and renaming them to "Weezer.mp3" or "Weezer.jpg" (the
image must be 600x600 otherwise it'll look weird I think)

Share with your friends!