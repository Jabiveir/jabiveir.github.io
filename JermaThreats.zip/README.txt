This is a very stupid project I made for funsies

-Green increases a setting, red decreases
-Volume is obvious, goes from 0 to 100
-Frequency is how long it takes to attempt to play a sound (in seconds)
-Chance is the chance it plays a sound every [Frequency] seconds (0%-100%)
-Step controls by how much each setting increases or decreases when clicked
-The sound it plays is randomly selected from the 8 sound files

The sounds it plays can be customized by replacing the files, but you have to
rename the new file to the exact name of whichever file you replaced (because I
didn't think about that)

Enjoy turning the settings low, minimizing it, and getting scared sometimes